$headslot = 5;
$bodyslot = 7;
$headMount = 2;
$bodyMount = 3;

//SKULL HELMET

datablock ItemData(SkullHelmetItem)
{
  uiName = "Skeleton Helmet";
  iconName = "./icon_skullhelmet";
  image = SkullHelmetImage;
  category = "Tools";
  className = "Weapon";
  shapeFile = "./a_skullhelmet.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61 1";
  canDrop = true;
};

datablock shapeBaseImageData(SkullHelmetImage)
{
  shapeFile = "./a_skullhelmet.dts";
  emap = true;
  mountPoint = 0;
  className = "WeaponImage";
  item = SkullHelmetItem;
  melee = false;
  doReaction = false;
  offset = "0.5575 0.85 -0.665";
  armReady = true;
  doColorShift = true;
  rotation = eulerToMatrix("0 0 0");
  colorShiftColor = "0.73 0.72 0.61 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

datablock ShapeBaseImageData(SkullHelmetMountedImage)
{
  shapeFile = "./a_skullhelmet.dts";
  emap = true;
  mountPoint = $HeadSlot;
  offset = "0.5575 0.85 -0.665";
  eyeOffset = "0 0 10";
  rotation = eulerToMatrix("0 0 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61";

  stateName[0] = "Idle";
  stateAllowImageChange[0] = true;
};

//PIRATE SKULL HELMET

datablock ItemData(PirateSkullHelmetItem)
{
  uiName = "Skeleneer Helmet";
  iconName = "./icon_pirateskullhelmet";
  image = PirateSkullHelmetImage;
  category = "Tools";
  className = "Weapon";
  shapeFile = "./a_pirateskullhelmet.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(PirateSkullHelmetImage)
{
  shapeFile = "./a_pirateskullhelmet.dts";
  emap = true;
  mountPoint = 0;
  className = "WeaponImage";
  item = PirateSkullHelmetItem;
  melee = false;
  doReaction = false;
  offset = "0.5575 0.85 -0.665";
  armReady = true;
  doColorShift = true;
  rotation = eulerToMatrix("0 0 0");
  colorShiftColor = "0.73 0.72 0.61 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

datablock ShapeBaseImageData(PirateSkullHelmetMountedImage)
{
  shapeFile = "./a_pirateskullhelmet.dts";
  emap = true;
  mountPoint = $HeadSlot;
  offset = "0.5575 0.85 -0.665";
  eyeOffset = "0 0 10";
  rotation = eulerToMatrix("0 0 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61";

  stateName[0] = "Idle";
  stateAllowImageChange[0] = true;
};






//Putting them RIBS ON THE GRILL
datablock ItemData(RibArmorItem)
{
  uiName = "Skeleton Armor";
  iconName = "./icon_ribarmor";
  image = RibArmorImage;
  category = "Tools";
  className = "Weapon";
  shapeFile = "./a_ribarmor.dts";
  mass = 1;
  density = 0.2;
  elasticity = 0;
  friction = 0.6;
  emap = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61 1";
  canDrop = true;
};

//### Item Image

datablock shapeBaseImageData(RibArmorImage)
{
  shapeFile = "./a_ribarmor.dts";
  emap = true;
  mountPoint = 0;
  className = "WeaponImage";
  item = RibArmorItem;
  melee = false;
  doReaction = false;
  armReady = true;
    offset = "0.5575 1.3 0";
  doColorShift = true;
  rotation = eulerToMatrix("0 0 0");
  colorShiftColor = "0.73 0.72 0.61 1";

  stateName[0] = "Activate";
  stateTimeoutValue[0] = 0.1;
  stateTransitionOnTimeout[0] = "Ready";
  stateSound[0] = weaponSwitchSound;

  stateName[1] = "Ready";
  stateTransitionOnTriggerDown[1] = "Fire";
  stateAllowImageChange[1] = true;

  stateName[2] = "Fire";
  stateTransitionOnTriggerUp[2] = "Ready";
  stateTimeoutValue[2] = "0.2";
  stateFire[2] = true;
  stateAllowImageChange[2] = true;
  stateScript[2] = "onFire";
};

datablock ShapeBaseImageData(RibArmorMountedImage)
{
  shapeFile = "./a_ribarmor.dts";
  emap = true;
  mountPoint = $bodyslot;
  offset = "0.557 0.85 0.905";
  eyeOffset = "0 0 10";
  rotation = eulerToMatrix("0 0 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61";
  isArmor = 1;

  stateName[0] = "Idle";
  stateAllowImageChange[0] = true;
};

function SkullHelmetImage::onFire(%this,%obj,%slot)
{
  %client = %obj.client;
  %player = %obj;
  if(isObject(%player))
  {
    if(%player.getMountedImage($headmount) $= nametoID(SkullHelmetMountedImage)) %player.unmountImage($headmount);
    else
    {
      %player.unmountImage($headmount);
      %player.mountImage(SkullHelmetMountedImage,$headmount);
    }
  }
}

function PirateSkullHelmetImage::onFire(%this,%obj,%slot)
{
  %client = %obj.client;
  %player = %obj;
  if(isObject(%player))
  {
    if(%player.getMountedImage($headmount) $= nametoID(PirateSkullHelmetMountedImage)) %player.unmountImage($headmount);
    else
    {
      %player.unmountImage($headmount);
      %player.mountImage(PirateSkullHelmetMountedImage,$headmount);
    }
  }
}

function RibArmorImage::onFire(%this,%obj,%slot)
{
  %client = %obj.client;
  %player = %obj;
  if(isObject(%player))
  {
    if(%player.getMountedImage($bodyMount) $= nametoID(RibArmorMountedImage)) %player.unmountImage($bodyMount);
    else
    {
      %player.unmountImage($bodyMount);
      %player.mountImage(RibArmorMountedImage,$bodyMount);
    }
  }
}


// SKELETON ARMOR
function RibArmorMountedImage::onMount(%this,%obj,%slot) 
{
    %obj.hideNode(armor); %obj.hideNode(pack); %obj.hideNode(quiver); %obj.hideNode(tank); %obj.hideNode(bucket); %obj.hideNode(cape); %obj.hideNode(epaulets); %obj.hideNode(epauletsRankA); %obj.hideNode(epauletsRankB); %obj.hideNode(epauletsRankC); %obj.hideNode(epauletsRankD); %obj.hidenode(shoulderpads);
    messageClient(%obj.client,"","\c7You put on the \c0Skeleton Armor\c7 (\c2+13%\c6 Regular Damage Protection \c7& \c2+20% <color:BBBB99>Bone Damage Protection\c7)!"); 
}
function RibArmorMountedImage::onUnMount(%this,%obj,%slot) 
{ 
    messageClient(%obj.client,"","\c7You took off the \c0Skeleton Armor\c7 (\c0-13%\c6 Regular Damage Protection \c7& \c0-20% <color:BBBB99>Bone Damage Protection\c7)!"); 
}

// SKELETON HELMET
function SkullHelmetMountedImage::onMount(%this,%obj,%slot) 
{
    %obj.hideNode(bicorn); %obj.hideNode(cophat); %obj.hideNode(triplume); %obj.hideNode(flarehelmet); %obj.hideNode(helmet); %obj.hideNode(knithat); %obj.hideNode(plume); %obj.hideNode(pointyhelmet); %obj.hideNode(scouthat); %obj.hideNode(septplume); %obj.hideNode(visor);
    messageClient(%obj.client,"","\c7You put on the \c0Skeleton Helmet\c7 (\c2+7%\c6 Regular Damage Protection \c7& \c2+10% <color:BBBB99>Bone Damage Protection\c7)!"); 
}
function SkullHelmetMountedImage::onUnMount(%this,%obj,%slot) 
{ 
    messageClient(%obj.client,"","\c7You took off the \c0Skeleton Helmet\c7 (\c0-7%\c6 Regular Damage Protection \c7& \c0-10% <color:BBBB99>Bone Damage Protection\c7)!"); 
}

// PIRATE SKELETON HELMET
function PirateSkullHelmetMountedImage::onMount(%this,%obj,%slot) 
{
    %obj.hideNode(bicorn); %obj.hideNode(cophat); %obj.hideNode(triplume); %obj.hideNode(flarehelmet); %obj.hideNode(helmet); %obj.hideNode(knithat); %obj.hideNode(plume); %obj.hideNode(pointyhelmet); %obj.hideNode(scouthat); %obj.hideNode(septplume); %obj.hideNode(visor);
    messageClient(%obj.client,"","\c7You put on the \c0Skeleneer Helmet\c7 (\c2+10%<color:BBBB99> Bone Damage Protection \c7& \c2+15% \c6Cutlass Damage\c7)!"); 
}
function PirateSkullHelmetMountedImage::onUnMount(%this,%obj,%slot) 
{ 
    messageClient(%obj.client,"","\c7You took off the \c0Skeleneer Helmet\c7 (\c0-10%<color:BBBB99> Bone Damage Protection \c7& \c0-15% \c6Cutlass Damage\c7)!"); 
}

package skeletonArmor
{
  function servercmdDropTool(%this,%slot)
  {
    if(isobject(%this.player.tool[%slot]) && %this.player.tool[%slot].getname() $= "RibArmorItem")
    {
        if(isobject(%this.player.getmountedimage($bodyMount)) && %this.player.getmountedimage($bodyMount).getname() $= "RibArmorMountedImage")
        { 
            %this.player.schedule(5,unmountimage,$bodyMount); 
        }
    }

    if(isobject(%this.player.tool[%slot]) && %this.player.tool[%slot].getname() $= "SkullHelmetItem")
    {
        if(isobject(%this.player.getmountedimage($headmount)) && %this.player.getmountedimage($headmount).getname() $= "SkullHelmetMountedImage")
        { 
            %this.player.schedule(5,unmountimage,$headmount); 
        }
    }
      if(isobject(%this.player.tool[%slot]) && %this.player.tool[%slot].getname() $= "PirateSkullHelmetItem")
    {
        if(isobject(%this.player.getmountedimage($headmount)) && %this.player.getmountedimage($headmount).getname() $= "PirateSkullHelmetMountedImage")
        { 
            %this.player.schedule(5,unmountimage,$headmount); 
        }
    }
      parent::servercmdDropTool(%this,%slot);

  }
  function Armor::Damage(%this,%obj,%sourceObject,%pos,%damage,%damageType)
  {
    %type = "";
    %class = "";
      if(%sourceobject.getClassName() $= "Projectile")
      {
          %type = %sourceObject.sourceObject.getMountedImage(0).specialDamageType;
          %class = %sourceObject.sourceObject.getMountedImage(0).weaponClass;
          %so = %sourceObject.sourceObject;
      }
      else
      {
          %type = %sourceObject.getMountedImage(0).specialDamageType;
          %class = %sourceObject.getMountedImage(0).weaponClass;
          %so = %sourceObject;
      }
    if(%class $= "Cutlass" && %so.getMountedImage($headmount).getName() $= "PirateSkullHelmetMountedImage")
    {
        %damage *= 1.4;
        //announce("Cutlass extra damage result: " @ %damage);
    }
      
    if(isObject(%obj.getMountedImage($bodyMount))) 
    {
        if(%obj.getMountedImage($bodyMount).getName() $= "RibArmorMountedImage")
        {
            if(%type $= "Bone")
            {
                %damage *= 0.8;
                //announce(%type SPC %damage);
            }
            else
            {
                %damage *= 0.87;
                //announce("I AINT GOT NO TYPE"SPC %type);
            }
        }
    }
      if(isObject(%obj.getMountedImage($headmount))) 
    {
        if(%obj.getMountedImage($headmount).getName() $= "SkullHelmetMountedImage")
        {
            if(%type $= "Bone")
            {
                %damage *= 0.9;
                //announce(%type SPC %damage);
            }
            else
            {
                %damage *= 0.93;
                //announce("I AINT GOT NO TYPE" SPC %type);
            }
        }
        if(%obj.getMountedImage($headmount).getName() $= "PirateSkullHelmetMountedImage")
        {
            if(%type $= "Bone")
            {
                %damage *= 0.9;
                //announce(%type SPC %damage);
            }
            
        }
    }
    parent::Damage(%this,%obj,%sourceObject,%pos,%damage,%damageType);
  }
    function Player::mountImage(%player, %image, %slot, %loaded, %skin) {
        %image2 = %player.getMountedImage($bodyMount);
        if(!((%image.stateEmitter[1]) $= "")) //Prevents console spam about not being able to find the className
        {
            if(%image.stateEmitter[1].getClassName() $= "ParticleEmitterData" && isObject(%image2) && %image2.isArmor)
            {
                //Disabling all emitter-based images will also disable the brick-trail. so we exclude this:
                if(%image.stateEmitter[1] $= "brickTrailEmitter")
                    return parent::mountImage(%player, %image, %slot, %loaded, %skin);
            
                //Everything else is ignored
                return;
            }
        }
        return parent::mountImage(%player, %image, %slot, %loaded, %skin);
	}
};
deactivatepackage(skeletonArmor);
activatepackage(skeletonArmor);

