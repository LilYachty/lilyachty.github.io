   exec("./Support_RaycastingWeapons.cs");
exec("./Support_TF2basicmelee.cs");
   exec("./Weapon_Boneaxe.cs");
   exec("./Weapon_Bonegreatsword.cs");
   exec("./Weapon_Bonesword.cs");
   exec("./Weapon_Bonehammer.cs");
   exec("./Weapon_BoneCutlass.cs");
   exec("./Item_SkeletonArmor.cs");

datablock AudioProfile(boneswingsound)
{
	filename    = "./swing.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(boneAxeSound)
{
	filename    = "./boneaxe.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(bloodHitSound)
{
	filename    = "./bloodhit.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(bonehammerSound)
{
	filename    = "./bonehammer.wav";
	description = AudioClose3d;
	preload = true;
};





