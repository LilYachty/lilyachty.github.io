$larmslot = 1;

datablock ItemData(boneswordItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./bonesword.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Skeleton Sword & Shield";
	iconName = "./icon_boneshield";
	doColorShift = true;
	colorShiftColor = "0.68 0.69 0.58 1.000";

	 // Dynamic properties defined by the scripts
	image = boneswordImage;
	canDrop = true;
};

datablock ShapeBaseImageData(BoneShieldImage)
{
  shapeFile = "./boneshield.dts";
  emap = true;
  mountPoint = $larmslot;
  offset = "-0.05 0 0";
  eyeOffset = "-0.6 0.3 -0.8";
  rotation = eulerToMatrix("0 10 0");
  scale = "1 1 1";
  correctMuzzleVector = true;
  doColorShift = true;
  colorShiftColor = "0.73 0.72 0.61";

  stateName[0] = "Idle";
  stateAllowImageChange[0] = true;
};

////////////////
//weapon image//
////////////////
AddDamageType("bonesword",   '<bitmap:base/client/ui/CI/generic><bitmap:base/client/ui/CI/skull> %1',    '%2 <bitmap:base/client/ui/CI/generic><bitmap:base/client/ui/CI/skull> %1',0.75,1);
datablock ShapeBaseImageData(boneswordImage)
{
   shapeFile = "./bonesword.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 0.0 0.0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";
    SpecialDamageType = "Bone";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "tf2MeleeWeaponImage";

   // Projectile && Ammo.
   item = boneswordItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = boneswordItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = boneaxesound;
   raycastExplosionPlayerSound = bloodhitsound;
   raycastDirectDamage = 17;
   raycastDirectDamageType = $DamageType::bonesword;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateSequence[0]                 = "Activate";
	stateTransitionOnTimeout[0]      = "Ready";
	stateScript[0]                  = "onActivate";
	stateSound[0]                    = weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.05;
	stateTransitionOnTimeout[2]     = "FireA";
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "FireB";
	stateTimeoutValue[3]            = 0.1;
	stateAllowImageChange[3]        = false;
	stateSound[3]			= boneswingsound;
	stateScript[3]                  = "onFireB";
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "FireB";
	stateTransitionOnTimeout[4]     = "Wait";
	stateTimeoutValue[4]            = 0.2;
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		= true;
	
	stateName[5]			= "Wait";
	stateTransitionOnTimeout[5]	= "CheckFire";
	stateTimeoutValue[5]		= 0.05;
	stateScript[5]			= "onStopFire";
	stateAllowImageChange[5]	= false;
	stateWaitForTimeout[5]		= true;

	stateName[6]			= "CheckFire";
	stateTransitionOnTriggerUp[6]	= "StopFire";
	stateTransitionOnTriggerDown[6]	= "PreFire";
	
	stateName[7]                    = "StopFire";
	stateTransitionOnTimeout[7]     = "Ready";
	stateTimeoutValue[7]            = 0.2;
	stateAllowImageChange[7]        = false;
	stateWaitForTimeout[7]		= true;
	stateSequence[7]                = "StopFire";
	stateScript[7]                  = "onStopFire";
};

function boneswordImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);

		%this.raycastExplosionBrickSound = boneaxesound;
		%this.raycastExplosionPlayerSound = bloodhitsound;

	WeaponImage::onFire(%this, %obj, %slot);
}

function boneswordImage::onFireB(%this, %obj, %slot)
{
	//%obj.playthread(2, shiftaway);
}

function boneswordImage::onActivate(%this, %obj, %slot)
{
	%obj.playthread(2, plant);
}

function boneswordImage::onMount(%this,%obj,%slot)
   {
      Parent::onMount(%this,%obj,%slot);
      %obj.mountImage(BoneShieldImage,$larmslot);
      %obj.playthread(1, armReadyBoth);
   }
   
   function boneswordImage::onUnMount(%this,%obj,%slot)
   {
      Parent::onUnMount(%this,%obj,%slot);
      %obj.unMountImage($larmslot);
      %obj.playthread(1, root);
      %obj.playthread(1, armreadyright);
   }

package lmao
{

function shieldBlock(%obj)
{
    
}
    
function Armor::Damage(%this,%obj,%sourceObject,%pos,%damage,%damageType)
  {
    parent::Damage(%this,%obj,%sourceObject,%pos,%damage,%damageType);
    if(isObject(%obj.getMountedImage(1))) 
    {
        if(%obj.getMountedImage(1).getName() $= "BoneShieldImage")
        {
            //announce(%damage SPC ":(");
            if(getRandom(0,3) == 3)
            {
                %damage *= 0.1;
                //announce("BLOCKED!" SPC %damage SPC %obj.getclassname());
            }
        }
    }
    
  }};
deactivatepackage(lmao);
activatepackage(lmao);