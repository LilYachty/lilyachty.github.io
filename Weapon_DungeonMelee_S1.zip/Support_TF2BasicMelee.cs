%path = "./";

datablock AudioProfile(boneswingsound)
{
   filename    = %path @ "swing.wav";
   description = AudioClosest3d;
   preload = true;
};

function tf2MeleeWeaponImage::onMount(%this, %obj, %slot)
{
	WeaponImage::onMount(%this, %obj, %slot);
}

function tf2MeleeWeaponImage::onUnMount(%this, %obj, %slot)
{
	WeaponImage::onUnMount(%this, %obj, %slot);
	%obj.playThread(2,root);
}

function tf2MeleeWeaponImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, shiftAway);
}

function tf2MeleeWeaponImage::onFire(%this, %obj, %slot)
{
	WeaponImage::onFire(%this, %obj, %slot);
	%obj.playthread(2, wrench);
}

function tf2MeleeWeaponImage::onStopFire(%this, %obj, %slot)
{	
	//%obj.playthread(2, root);
}

function tf2MeleeWeaponImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   WeaponImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit);
}

function tf2MeleeWeaponImage::onRaycastDamage(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   WeaponImage::onRaycastDamage(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit);
}

function tf2MeleeWeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit)
{
   if(isObject(%obj) && (%obj.getType() & $TypeMasks::PlayerObjectType) && %col.iszombie)
   {
       return 1;
   }
   return WeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit);
}
