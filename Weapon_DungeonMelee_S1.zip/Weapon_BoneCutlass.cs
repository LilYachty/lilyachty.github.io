$larmslot = 1;

datablock ItemData(bonecutlassItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./bonecutlass.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Skeleton Cutlasses";
	iconName = "./icon_bonecutlass";
	doColorShift = true;
	colorShiftColor = "0.68 0.69 0.58 1.000";

	 // Dynamic properties defined by the scripts
	image = bonecutlassImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
AddDamageType("bonecutlass",   '<bitmap:base/client/ui/CI/generic><bitmap:base/client/ui/CI/skull> %1',    '%2 <bitmap:base/client/ui/CI/generic><bitmap:base/client/ui/CI/skull> %1',0.75,1);
datablock ShapeBaseImageData(bonecutlassImage)
{
   shapeFile = "./bonecutlass.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 0.0 0.0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";
    SpecialDamageType = "Bone";
    weaponClass = "Cutlass";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "tf2MeleeWeaponImage";

   // Projectile && Ammo.
   item = bonecutlassItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = bonecutlassItem.colorShiftColor;
   
   raycastWeaponRange = 4;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = boneaxesound;
   raycastExplosionPlayerSound = bloodhitsound;
   raycastDirectDamage = 10;
   raycastDirectDamageType = $DamageType::bonecutlass;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.5;
	stateSequence[0] = "Activate";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Shoot";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.1;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	statesound[2]			= boneswingsound;

	stateName[3] = "Swingpause";
	stateAllowImageChange[3] = false;
	stateTransitionOnTriggerUp[3] = "AkimboFire";
		stateTransitionOnTriggerDown[3] = "AkimboFire";
	stateSequence[3] = "ready";

	stateName[4] = "Shoot";
	stateFire[4] = true;
	stateTransitionOnTimeout[4] = "Swingpause";
	stateTimeoutValue[4] = 0.0;

	stateName[5] = "AkimboFire";
	stateTimeoutValue[5] = 0.1;
	stateScript[5] = "onAkimboFire";
	stateTransitionOnTimeOut[5] = "refire";

	   stateName[6] = "refire";
	stateTransitionOnTriggerDown[6] = "Fire";
		stateTransitionOnTriggerUp[6] = "Ready";
	stateTimeoutValue[6]            = 0.01;
	stateTransitionOnTimeout[6]     = "Swingpause";
};
function BoneCutlassImage::onFireAkimbo(%this,%obj,%slot)
{
   %obj.setImageTrigger(1,1);
}

datablock ShapeBaseImageData(leftbonecutlassImage)
{
   shapeFile = "./bonecutlass.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 1;
   offset = "0.0 0.0 0.0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";
    SpecialDamageType = "Bone";
    weaponClass = "Cutlass";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "tf2MeleeWeaponImage";

   // Projectile && Ammo.
   item = bonecutlassItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = false;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = bonecutlassItem.colorShiftColor;
   
   raycastWeaponRange = 4;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = boneaxesound;
   raycastExplosionPlayerSound = bloodhitsound;
   raycastDirectDamage = 10;
   raycastDirectDamageType = $DamageType::bonecutlass;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0] = "Activate";
	stateTransitionOnTimeout[0] = "Ready";
	stateTimeoutValue[0] = 0.5;
	stateSequence[0] = "Activate";

	stateName[1] = "Ready";
	stateSequence[1] = "ready";
	stateTransitionOnTriggerDown[1] = "Fire";

	stateName[2] = "Fire";
	stateSequence[2] = "Fire";
	stateTransitionOnTimeout[2] = "Shoot";
   stateWaitForTimeout[2] = true;
	stateTimeoutValue[2] = 0.1;
	stateAllowImageChange[2] = false;
	stateScript[2] = "onFire";
	statesound[2]			= boneswingSound;

	stateName[3] = "Swingpause";
	stateAllowImageChange[3] = false;
	stateTransitionOnTriggerUp[3] = "Ready";
	stateSequence[3] = "ready";

	stateName[4] = "Shoot";
	stateFire[4] = true;
	stateTransitionOnTimeout[4] = "Swingpause";
	stateTimeoutValue[4] = 0.0;
};

function bonecutlassImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   //mount
   %obj.mountImage(LeftbonecutlassImage, 1);
    %obj.playThread(1, armreadyboth);
   //%obj.playThread(0, armreadyboth);
}

function bonecutlassImage::onFire(%this, %obj, %slot)
{
    parent::onFire(%this,%obj,%slot);
    %obj.playThread(1, activate2);
    schedule(100,0,%obj,playthread,1,activate2);
}
function bonecutlassImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
   //unmount
   %obj.unMountImage(1);
    
   //%obj.playThread(0, root);
}


function LeftbonecutlassImage::onMount(%this, %obj, %slot)
{
   Parent::onMount(%this, %obj, %slot);
   %obj.playThread(1, armreadyboth);
}
function LeftbonecutlassImage::onUnMount(%this, %obj, %slot)
{
   Parent::onUnMount(%this, %obj, %slot);
}